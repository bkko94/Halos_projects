package com.mysite.askAnything;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AskAnythingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AskAnythingApplication.class, args);
	}

}
