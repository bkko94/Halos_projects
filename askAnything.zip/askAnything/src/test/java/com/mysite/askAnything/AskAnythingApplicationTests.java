package com.mysite.askAnything;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AskAnythingApplicationTests {

	@Test
	void contextLoads() {
	}

}
